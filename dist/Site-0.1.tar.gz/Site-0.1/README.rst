=====
Rush01
=====

Rush01 is a Django app to write posts.

Quick start
-----------

1. Add "Site" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'Site.app.SiteConfig',
    ]

2. Include the ex URLconf in your project urls.py like this::

    path('Site/', include('Site.urls')),

3. Run ``python manage.py migrate`` to create the ex models.

4. Start the development server and visit http://127.0.0.1:8000/admin/
   to create a Site (you'll need the Admin app enabled).

5. Visit http://127.0.0.1:8000/ to write posts.
