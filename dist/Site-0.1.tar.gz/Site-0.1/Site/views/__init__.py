from	.main							import	Main
from	.login							import	Login
from	.logout							import	Logout
from	.register						import	Register
from	.message						import	DiscussionDetailView, DiscussionListView
from	.profile						import	ProfileView
from	.post							import	PostView, PostDetailView, PostEditView, PostDeleteView
from	.comment						import	CommentView, CommentDeleteView